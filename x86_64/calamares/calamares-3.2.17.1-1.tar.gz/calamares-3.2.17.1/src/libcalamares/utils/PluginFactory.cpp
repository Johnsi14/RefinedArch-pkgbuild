/* === This file is part of Calamares - <https://github.com/calamares> ===
 *
 *   Copyright 2019, Adriaan de Groot <groot@kde.org>
 *
 */

#include "PluginFactory.h"

CalamaresPluginFactory::~CalamaresPluginFactory() {}
